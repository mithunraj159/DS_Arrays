import UIKit

/*
 Question
 Given an array arr[] of size N, the task is to find the largest element in the given array.

 Examples:

 Input: arr[] = {10, 20, 4}
 Output: 20
 Explanation: Among 10, 20 and 4, 20 is the largest.

 Input : arr[] = {20, 10, 20, 4, 100}
 Output : 100
 
 */

func largestElementInArrayLogic(array:[Int]) -> Int  {
    var largestElement = array[0]
    
    for i in 0..<array.count {
        if array[i] > largestElement {
            largestElement = array[i]
        }
    }
    return largestElement
}

print(largestElementInArrayLogic(array: [8, 5, 9, 10, 3]))
