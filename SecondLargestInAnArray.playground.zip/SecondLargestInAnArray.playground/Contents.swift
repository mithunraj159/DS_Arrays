import UIKit

/*
 Question:
 
 Given an array of integers, our task is to write a program that efficiently finds the second-largest element present in the array.

 Examples:

 Input: arr[] = {12, 35, 1, 10, 34, 1}
 Output: The second largest element is 34.
 Explanation: The largest element of the array is 35 and the second largest element is 34

 Input: arr[] = {10, 5, 10}
 Output: The second largest element is 5.
 Explanation: The largest element of the array is 10 and the second largest element is 5

 Input: arr[] = {10, 10, 10}
 Output: The second largest does not exist.
 Explanation: Largest element of the array is 10 there is no second largest element
 */
func logicForSecondLargestElement(arr: [Int]) -> Int {
    var largestElement = arr[0]
    var secondLargest = 0
    
    for i in 0..<arr.count {
        if arr[i] > largestElement {
            secondLargest = largestElement
            largestElement = arr[i]
        } else if arr[i] > secondLargest && arr[i] < largestElement {
            secondLargest = arr[i]
        }
        
    }
    return secondLargest
}


//print("second largest element in the array is \(logicForSecondLargestElement(arr: [12, 35, 1, 10, 34, 1]))")
print("second largest element in the array is \(logicForSecondLargestElement(arr: [10, 5, 10]))")
//print("second largest element in the array is \(logicForSecondLargestElement(arr: [10, 10, 10]))")

